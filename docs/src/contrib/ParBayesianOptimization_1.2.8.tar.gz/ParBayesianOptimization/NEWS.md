# ParBayesianOptimization News

## Version Updates

## 1.2.8

* Fixed `bayesOpt()` `xgboost` example.
* Stopped sinking of `bayesOpt()` FUN output.

## 1.2.7

* Fixed compatibility errors with xgboost in the vignettes and testing programs.

## 1.2.5
* Fixed a reproducibility bug.

## 1.2.4

* Fixed a small bug that allowed duplicates to make their way into the candidate table.

## 1.2.3

* Some suggested packages are now used conditionally in vignettes, reade, tests and examples since they might not be available on all checking machines.

## 1.2.2

* Removed Plotly from dependencies.

## 1.2.1  

* Fixed a bug with initgrid on scoring functions with dimensionality over 4.

## 1.2.0

* Improved the way error handling works - any errors encountered in initialization will be returned.

## 1.1.0

* Changed Gaussian Process package to DiceKriging. predict method is much faster.
* Added errorHandling parameter - bayesOpt() and addIterations() should now return results no matter what, unless errorHandling = 'stop'.
* Added otherHalting parameter.
