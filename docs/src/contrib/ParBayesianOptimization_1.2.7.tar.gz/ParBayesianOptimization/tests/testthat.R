library(testthat)
library(ParBayesianOptimization)

test_check("ParBayesianOptimization")
